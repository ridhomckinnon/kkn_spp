<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> 
        <a href="/dashboard" class="no-underline text-rose-500 hover:text-rose-700"><i class="fa fa-arrow-left"></i> Kembali</a>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('main', null, ['class' => '']); ?> 
        <div class="flex">
            <div class="w-4/6">
                <div class="bg-white px-4 pt-4 border rounded-xl">
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('transaction.student', ['id_classes' => $class->id])); ?>"
                            class="block no-underline text-gray-500 px-4 py-2 border rounded-xl capitalize mb-4">
                            <div class="flex items-center justify-between">
                                <?php echo e($class->name); ?>

                                <i class="fa fa-chevron-right"></i>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>
        

     <?php $__env->endSlot(); ?>
    <div class="max-w-7xl mx-auto  bg-white mt-4">
    </div>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            // $(document).ready(function() {

            //     $.ajaxSetup({
            //         headers: {
            //             'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            //         }
            //     });

            //     // Confirm Delete
            //     $(".btnConfirm").click(function() {
            //         var href = $(this).data('href');
            //         $("#btnDelete").attr('href', href)
            //     });

            //     $('.btnEdit').click(function() {
            //         var id = $(this).data('id')
            //         var url = $(this).data('url')
            //         $.get(url + "/student/" + id, function({
            //             data
            //         }) {
            //             $('#idStudent').val(data.id);
            //             $('#nis').val(data.nis);
            //             $('#name').val(data.name);
            //             $('#id_classes').val(data.id_classes);
            //             $('#id_period').val(data.id_period);
            //             $('#address').val(data.address);
            //         })
            //     })
            // });
        </script>
     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /media/sanz/Data1/kkn_spp/resources/views/transaction.blade.php ENDPATH**/ ?>