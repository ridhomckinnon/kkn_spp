<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> 
        <a href="/mutation" class="no-underline text-rose-500 hover:text-rose-700"><i class="fa fa-arrow-left"></i> Kembali</a>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('main', null, []); ?> 
        <div class="">

            <div class="border rounded-xl p-4 mb-4">
                <div>
                    <h4 class="font-semibold capitalize"><?php echo e($student->name); ?></h4>
                    <!-- <p class="font-light">this page for student</p> -->
                </div>

                <div>
                    <p>Nis  <span>: <?php echo e($student->nis); ?></span></p>
                    <p>Tahun Ajaran <span>: <?php echo e($student->period->school_year); ?></span></p>
                    <p>Kelas  <span>: <?php echo e($student->classes->name); ?></span></p>
                    <p>Jurusan <span>: <?php echo e($student->major); ?></span></p>

                </div>
            </div>
            <div class="border rounded-xl p-4 mb-4">
                <div class="">
                    <h4 class="font-semibold capitalize">Transaksi terakhir</h4>
                    <table id="" class="table-auto w-full border overflow-hidden rounded-xl">
                        <thead class="bg-slate-100 mt-4">
                            <tr>
                                <th class="font-bold p-4 text-gray-500 text-left">#</th>
                                <th class="font-bold p-4 text-gray-500 text-left">Bulan</th>
                                <th class="font-bold p-4 text-gray-500 text-left">Tahun</th>
                                <th class="font-bold p-4 text-gray-500 text-left">Jumlah</th>
                                <th class="font-bold p-4 text-gray-500 text-left">Tanggal Bayar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($loop->iteration); ?>

                                    </td>
                                    <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e(bulan($data->bulan)); ?></td>
                                    <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($data->tahun); ?></td>
                                    <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($data->jumlah); ?></td>
                                    <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($data->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>

            <div class="border rounded-xl p-4">
                <div>
                    <h4 class="font-semibold">Cetak Bukti Bayar</h4>
                </div>
                <form action='<?php echo e(url("mutation/cetak/$student->id")); ?>' method="post">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="">Dari : </label>
                        <input type="date" name="from" class="block bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">

                    </div>
                    <div class="mt-2">
                        <label for="">Sampai : </label>
                        <input type="date" name="to" class="block bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    </div>
                    <button type="submit" class="mt-4 bg-emerald-400 text-white py-3 px-4 rounded-xl">Cetak</button>
                </form>
                <div>
                </div>
            </div>
        </div>
     <?php $__env->endSlot(); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /media/sanz/Data1/kkn_spp/resources/views/detail-mutation.blade.php ENDPATH**/ ?>