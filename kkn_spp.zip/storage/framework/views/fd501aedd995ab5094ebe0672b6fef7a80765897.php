<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('heading', null, []); ?> 
        <a href="/dashboard" class="no-underline text-rose-500 hover:text-rose-700"><i class="fa fa-arrow-left"></i> Kembali</a>
     <?php $__env->endSlot(); ?>
     <?php $__env->slot('main', null, []); ?> 
        <div class="mb-4 relative flex justify-between align-middle items-center">
            <div class="w-2/6 flex justify-start">
                <div>
                    <h2 class="font-bold text-2xl">Mutasi</h2>
                    <!-- <p class="font-light">this page for student</p> -->
                </div>
            </div>
        </div>
        <div class="relative">
            <table id="dataTable" class="table-auto w-full border overflow-hidden rounded-xl">
                <thead class="bg-slate-100 mt-4">
                    <tr>
                        <th class="font-bold p-4 text-gray-500 text-left">#</th>
                        <th class="font-bold p-4 text-gray-500 text-left">Nis</th>
                        <th class="font-bold p-4 text-gray-500 text-left">Nama Siswa</th>
                        <th class="font-bold p-4 text-gray-500 text-left">Jenis Kelamin</th>
                        <th class="font-bold p-4 text-gray-500 text-left">Tahun Ajaran</th>
                        <th class="font-bold p-4 text-gray-500 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($loop->iteration); ?>

                            </td>
                            <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($data->nis); ?></td>
                            <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($data->name); ?></td>
                            <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e(($data->gender == "L") ? "Laki-laki" : "Perempuan"); ?></td>
                            <td class="text-left font-light p-4 border-b border-slate-100"><?php echo e($data->period->school_year); ?></td>
                            <td class="text-left border-b border-slate-100">
                                <a class="no-underline" href='<?php echo e(url("mutation/student/$data->id")); ?>'>Lihat Mutasi</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>

        </div>
     <?php $__env->endSlot(); ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH /media/sanz/Data1/kkn_spp/resources/views/mutation.blade.php ENDPATH**/ ?>