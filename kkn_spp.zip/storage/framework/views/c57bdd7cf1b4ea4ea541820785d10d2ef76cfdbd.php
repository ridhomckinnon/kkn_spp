<div class="h-screen flex flex-col justify-center items-center ">
    <div>
        <?php echo e($logo); ?>

    </div>

    <div class="w-full mt-6">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH /media/sanz/Data1/kkn_spp/resources/views/components/auth-card.blade.php ENDPATH**/ ?>