<div class="mb-4 relative flex justify-between align-middle items-center">
    <div class="relative overflow-hidden border rounded-xl mt-4">
        <table class="table-auto w-full ">
            <thead class="bg-slate-100 text-white border-b">

            </thead>
            <tbody>

            </tbody>
        </table>
    </div>
</div>
