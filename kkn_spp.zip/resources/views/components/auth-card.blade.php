<div class="h-screen flex flex-col justify-center items-center ">
    <div>
        {{ $logo }}
    </div>

    <div class="w-full mt-6">
        {{ $slot }}
    </div>
</div>
