import Datepicker from 'flowbite-datepicker/Datepicker';
    const datepickerEl = document.getElementById('datepickerId');
new Datepicker(datepickerEl, {
    // options
});
